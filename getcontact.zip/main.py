from flask import Flask, send_file, request, jsonify
import io
import os
import pathlib
import re
import subprocess
import sys
import threading
import time
import traceback

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException


app = Flask(__name__)


STATE = {
    "driver": None,
    "wait": None,
    "init_error": None,
}

driver_lock = threading.Lock()
init_lock = threading.Lock()


def _runtime_root() -> str:
    return str(pathlib.Path(__file__).resolve().parent / ".runtime")


def _prepare_uc_env() -> None:
    root = _runtime_root()
    p = pathlib.Path(root)
    p.mkdir(parents=True, exist_ok=True)

    xdg_cache = str(p / "xdg_cache")
    xdg_config = str(p / "xdg_config")
    pathlib.Path(xdg_cache).mkdir(parents=True, exist_ok=True)
    pathlib.Path(xdg_config).mkdir(parents=True, exist_ok=True)
    os.environ["XDG_CACHE_HOME"] = xdg_cache
    os.environ["XDG_CONFIG_HOME"] = xdg_config


def _find_browser_executable() -> str | None:
    env_bin = os.environ.get("CHROME_BIN") or os.environ.get("CHROMIUM_BIN")
    if env_bin and os.path.exists(env_bin):
        return env_bin

    candidates = [
        "/snap/bin/chromium",
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
    ]
    for path in candidates:
        if os.path.exists(path):
            return path

    return None


def _detect_chrome_major(browser_executable_path: str) -> int | None:
    try:
        out = subprocess.check_output([browser_executable_path, "--version"], stderr=subprocess.STDOUT, text=True).strip()
    except Exception:
        return None

    m = re.search(r"(\d+)\.", out)
    if not m:
        return None

    try:
        return int(m.group(1))
    except Exception:
        return None


def _ensure_on_home(driver) -> None:
    try:
        if "web.getcontact.com" not in (driver.current_url or ""):
            driver.get("https://web.getcontact.com")
            time.sleep(2)
    except WebDriverException:
        driver.get("https://web.getcontact.com")
        time.sleep(2)


def _create_driver_once():
    _prepare_uc_env()
    import undetected_chromedriver as uc

    options = uc.ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")

    user_data_dir = str(pathlib.Path(_runtime_root()) / "chrome_profile")
    pathlib.Path(user_data_dir).mkdir(parents=True, exist_ok=True)
    browser_executable_path = _find_browser_executable()
    if not browser_executable_path:
        raise RuntimeError("Chrome/Chromium bulunamadı. CHROME_BIN=/snap/bin/chromium şeklinde ayarlayın.")

    options.binary_location = browser_executable_path
    version_main = _detect_chrome_major(browser_executable_path)

    driver = uc.Chrome(
        options=options,
        use_subprocess=True,
        user_data_dir=user_data_dir,
        browser_executable_path=browser_executable_path,
        version_main=version_main,
        user_multi_procs=False,
        patcher_force_close=True,
    )
    driver.set_page_load_timeout(60)
    wait = WebDriverWait(driver, 30)
    driver.get("https://web.getcontact.com")
    return driver, wait


def _init_driver():
    with init_lock:
        if STATE["driver"] is not None:
            return
        try:
            STATE["driver"], STATE["wait"] = _create_driver_once()
            STATE["init_error"] = None
        except Exception as e:
            STATE["driver"] = None
            STATE["wait"] = None
            STATE["init_error"] = f"{type(e).__name__}: {e}"

            runtime = _runtime_root()
            try:
                import shutil

                shutil.rmtree(os.path.join(runtime, "appdata", "undetected_chromedriver"), ignore_errors=True)
            except Exception:
                pass

            try:
                STATE["driver"], STATE["wait"] = _create_driver_once()
                STATE["init_error"] = None
            except Exception as e2:
                STATE["driver"] = None
                STATE["wait"] = None
                STATE["init_error"] = f"{type(e2).__name__}: {e2}"


def _get_driver():
    if STATE["driver"] is None:
        _init_driver()
    return STATE["driver"], STATE["wait"], STATE["init_error"]


def _set_country(driver, country: str) -> None:
    if not country or country.upper() == "TR":
        return

    country = country.upper()
    js = """
    const el = document.getElementById('numberCountryCode');
    if (!el) { return false; }
    el.value = arguments[0];
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
    """
    try:
        ok = driver.execute_script(js, country)
        if ok:
            time.sleep(0.5)
            return
    except Exception:
        pass

    try:
        container = driver.find_element(By.CSS_SELECTOR, ".sb-country")
        container.click()
        time.sleep(0.3)
        search_box = driver.find_element(By.CSS_SELECTOR, ".select2-search__field")
        search_box.send_keys(country)
        search_box.send_keys(Keys.ENTER)
        time.sleep(0.5)
    except Exception:
        pass


def _find_visible(driver, by, value, timeout_s: int):
    return WebDriverWait(driver, timeout_s).until(EC.visibility_of_element_located((by, value)))


@app.route("/durum")
def durum():
    driver, _, init_error = _get_driver()
    if not driver:
        return jsonify({"login": False, "msg": init_error or "Initializing"}), 503

    with driver_lock:
        try:
            _ensure_on_home(driver)
            if driver.find_elements(By.ID, "numberInput"):
                return jsonify({"login": True, "msg": "Ready"})
            return jsonify({"login": False, "msg": "Waiting for Login/QR"}), 401
        except Exception as e:
            return jsonify({"login": False, "msg": f"{type(e).__name__}: {e}"}), 500


@app.route("/get-qr-code")
def get_qr_code():
    driver, _, init_error = _get_driver()
    if not driver:
        return jsonify({"error": init_error or "Sürücü hazır değil"}), 503

    with driver_lock:
        try:
            _ensure_on_home(driver)

            try:
                refresh_btn = driver.find_element(By.CSS_SELECTOR, ".q-refresh .qr-button")
                if refresh_btn.is_displayed():
                    driver.execute_script("arguments[0].click();", refresh_btn)
                    time.sleep(1)
            except Exception:
                pass

            selectors = [
                ".qrcode img",
                ".qrcode canvas",
                "img[alt='Getcontact']",
            ]

            el = None
            for sel in selectors:
                try:
                    found = driver.find_element(By.CSS_SELECTOR, sel)
                    if found.is_displayed():
                        el = found
                        break
                except Exception:
                    continue

            if not el:
                return jsonify({"error": "QR kod bulunamadı veya oturum açık."}), 404

            img_bytes = el.screenshot_as_png
            return send_file(io.BytesIO(img_bytes), mimetype="image/png")
        except Exception as e:
            return jsonify({"error": f"{type(e).__name__}: {e}"}), 500


@app.route("/debug/screenshot")
def debug_screenshot():
    driver, _, init_error = _get_driver()
    if not driver:
        return jsonify({"error": init_error or "Sürücü hazır değil"}), 503

    with driver_lock:
        try:
            png = driver.get_screenshot_as_png()
            return send_file(io.BytesIO(png), mimetype="image/png")
        except Exception as e:
            return jsonify({"error": f"{type(e).__name__}: {e}"}), 500


@app.route("/api/gsm/<gsm>")
def api_gsm(gsm: str):
    driver, _, init_error = _get_driver()
    if not driver:
        return jsonify({"status": "error", "message": init_error or "Sürücü hazır değil", "gsm": gsm}), 503

    country = request.args.get("country", "TR").upper()
    timeout_s = request.args.get("timeout", "45")
    try:
        timeout_s = int(timeout_s)
    except Exception:
        timeout_s = 45

    with driver_lock:
        try:
            _ensure_on_home(driver)
            _set_country(driver, country)

            try:
                search_input = _find_visible(driver, By.ID, "numberInput", timeout_s=30)
            except TimeoutException:
                return jsonify({"status": "error", "message": "Sorgu kutusu bulunamadı (oturum kapalı olabilir).", "gsm": gsm}), 401

            search_input.click()
            search_input.send_keys(Keys.CONTROL + "a")
            search_input.send_keys(Keys.BACKSPACE)
            time.sleep(0.4)

            for ch in gsm:
                search_input.send_keys(ch)
                time.sleep(0.05)

            time.sleep(0.7)
            search_input.send_keys(Keys.ENTER)

            try:
                btn = driver.find_element(By.CSS_SELECTOR, ".searchForm button, button.search-btn")
                driver.execute_script("arguments[0].click();", btn)
            except Exception:
                try:
                    driver.execute_script("document.querySelector('.searchForm')?.dispatchEvent(new Event('submit', {bubbles:true,cancelable:true}));")
                    driver.execute_script("document.querySelector('.searchForm')?.submit();")
                except Exception:
                    pass

            success_selectors = [
                ".rpbi-info h1",
                "h1.name",
                ".contact-name",
            ]
            error_selectors = [
                ".captcha-container",
                ".q-refresh",
                ".not-found",
                ".no-result",
                ".error-wrapper",
            ]

            start = time.time()
            while time.time() - start < timeout_s:
                for sel in success_selectors:
                    try:
                        el = driver.find_element(By.CSS_SELECTOR, sel)
                        txt = (el.text or "").strip()
                        if el.is_displayed() and txt:
                            return jsonify({"status": "success", "gsm": gsm, "country": country, "result": txt})
                    except Exception:
                        continue

                for sel in error_selectors:
                    try:
                        el = driver.find_element(By.CSS_SELECTOR, sel)
                        if el.is_displayed():
                            if "captcha" in sel:
                                msg = "Captcha engeline takıldı."
                            elif "q-refresh" in sel:
                                msg = "Oturum kapalı veya QR yenilenmeli."
                            else:
                                msg = "Numara bulunamadı veya sistem engeli."
                            return jsonify({"status": "error", "gsm": gsm, "message": msg}), 403
                    except Exception:
                        continue

                time.sleep(1.2)

            return jsonify({"status": "error", "gsm": gsm, "message": "Sonuç bulunamadı veya zaman aşımı"}), 404
        except Exception as e:
            return jsonify(
                {
                    "status": "error",
                    "gsm": gsm,
                    "message": f"{type(e).__name__}: {e}",
                    "trace": traceback.format_exc().splitlines()[-8:],
                }
            ), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, threaded=True, debug=False)

