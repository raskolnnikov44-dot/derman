set -euo pipefail

APP_DIR="${APP_DIR:-/opt/getcontact}"
SERVICE_NAME="${SERVICE_NAME:-getcontact}"
PORT="${PORT:-5000}"
CHROME_BIN="${CHROME_BIN:-/snap/bin/chromium}"

if [ "$(id -u)" -eq 0 ]; then
  SUDO=""
else
  SUDO="sudo"
fi

$SUDO apt update
$SUDO apt -y install python3 python3-venv python3-pip python3-setuptools curl unzip ca-certificates rsync \
  libnss3 libatk-bridge2.0-0 libgtk-3-0 libx11-xcb1 libxcomposite1 libxdamage1 libxrandr2 libgbm1 libasound2 libatspi2.0-0 \
  fonts-liberation

if apt-cache show python3-distutils >/dev/null 2>&1; then
  $SUDO apt -y install python3-distutils || true
fi

if ! command -v chromium >/dev/null 2>&1 && ! command -v google-chrome >/dev/null 2>&1; then
  $SUDO apt -y install chromium chromium-driver || true
  if command -v snap >/dev/null 2>&1; then
    $SUDO snap install chromium || true
  fi
fi

if [ ! -x "$CHROME_BIN" ]; then
  if command -v chromium >/dev/null 2>&1; then
    CHROME_BIN="$(command -v chromium)"
  elif command -v google-chrome >/dev/null 2>&1; then
    CHROME_BIN="$(command -v google-chrome)"
  elif [ -x "/snap/bin/chromium" ]; then
    CHROME_BIN="/snap/bin/chromium"
  fi
fi

$SUDO mkdir -p "$APP_DIR"
$SUDO chown -R "$USER:$USER" "$APP_DIR" || true

rsync -a --delete \
  --exclude ".venv" \
  --exclude ".runtime" \
  --exclude "__pycache__" \
  --exclude "*.pyc" \
  "./" "$APP_DIR/"

cd "$APP_DIR"

python3 -m venv .venv
. .venv/bin/activate
pip install -U pip
pip install -U setuptools wheel
pip install flask selenium undetected-chromedriver
deactivate

UNIT_PATH="/etc/systemd/system/${SERVICE_NAME}.service"

$SUDO tee "$UNIT_PATH" >/dev/null <<EOF
[Unit]
Description=Getcontact API (Flask + Selenium)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=PORT=$PORT
Environment=CHROME_BIN=$CHROME_BIN
Environment=SETUPTOOLS_USE_DISTUTILS=local
ExecStart=$APP_DIR/.venv/bin/python $APP_DIR/main.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

$SUDO systemctl daemon-reload
$SUDO systemctl enable --now "$SERVICE_NAME"
$SUDO systemctl restart "$SERVICE_NAME"
$SUDO systemctl status "$SERVICE_NAME" --no-pager
